//console.log("I love JS");

const cool = require("cool-ascii-faces");

//console.log(cool());

const express = require("express");

var app = express();

var port = process.env.PORT || 80;

app.use("/", express.static("./public"));

app.get("/cool", (request, response) => {
	response.send("<html>"+cool()+"</html>");
});

app.listen(port, () => {
	console.log("Server ready");
})

console.log("Starting server")

